import logging

import core

import yaml

import logging.config

import os

def setup_logging(default_path='config.yaml', default_level=logging.INFO):

    path = default_path

    if os.path.exists(path):

        with open(path, 'r', encoding='utf-8') as f:

            config = yaml.load(f)
            logging.config.dictConfig(config)
    else:
        logging.basicConfig(level=default_level)

def log():

    logging.debug('Start')

    logging.info('Exec')

    logging.info('Finished')

if __name__ == '__main__':

    yaml_path = 'config.yaml'

    setup_logging(yaml_path)

    log()

    core.run()
        # for i in  range(10000):
        #     logger.debug('i={}'.format(i))
        #
        # log_files=glob.glob('{}*'.format(filename))
        # for name in sorted(log_files):
        #     logging.info(name)