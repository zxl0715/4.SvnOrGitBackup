import logging
import logging.handlers
import glob
filename='BackupLog.log'

logger=logging.getLogger('BackupLogger')
logger.setLevel(logging.DEBUG)

hander=logging.handers.RotatingFileHandler(filename,maxBytes=5*1024,bakcupCount=5)
logger.addHandler(hander)

for i in range(20):
    logger.debug('i={}'.format(i))


log_files=glob.glob('{}*'.format(filename))
for name  in sorted(log_files):
    print(name)

